This package contains utilities to quickly view and explore large amounts of data in a plot in MATLAB. See:

>> help LinePlotReducer

or

>> help reduce_plot

or

>> help LinePlotExplorer

for more info.

Thanks for downloading.

Tucker McClure
Copyright 2013, The MathWorks, Inc.
